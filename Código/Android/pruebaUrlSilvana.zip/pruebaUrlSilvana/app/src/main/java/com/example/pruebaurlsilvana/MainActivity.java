package com.example.pruebaurlsilvana;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.os.StrictMode;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.IOException;


public class MainActivity extends AppCompatActivity {

    private TextView textViewRespuesta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Necesario para permitir conexiones de red en el hilo principal (solo para este ejemplo)
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        textViewRespuesta = findViewById(R.id.text_view_respuesta);
        Button buttonGet = findViewById(R.id.button_get);

        buttonGet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String respuesta = NetworkUtils.realizarPeticionGET("http://10.0.2.2:3000");
                    Log.d("Respuesta", respuesta);
                    textViewRespuesta.setText("Respuesta: " + respuesta);
                } catch (IOException e) {
                    Log.e("Error", "Error al realizar la petición GET", e);
                    textViewRespuesta.setText("Error: " + e.getMessage());
                }
            }
        });
    }
}